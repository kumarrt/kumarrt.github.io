My Github website. Website template by -- Stuart Geiger -- is from the Minimal Mistakes Jekyll Theme, which is © 2016 Michael Rose and released under the MIT License. See LICENSE.md.
